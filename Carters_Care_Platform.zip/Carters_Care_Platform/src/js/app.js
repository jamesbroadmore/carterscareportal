let currentPage = 'dashboard';


async function goToPage(pageId) {
    // Check billing compliance before allowing access
    if (pageId === 'billing') {
        const isCompliant = await checkBillingCompliance();
        if (!isCompliant) {
            Toast.warning('Billing access is locked. Please complete all requirements first.');
            return;
        }
        // Refresh invoices list when entering billing page
        if (typeof refreshInvoicesList === 'function') {
            refreshInvoicesList();
        }
    }

    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.getElementById(`page-${pageId}`).classList.add('active');

    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    document.querySelector(`[data-page="${pageId}"]`).classList.add('active');

    const titles = {
        dashboard: 'Dashboard',
        clients: 'Client Management',
        staff: 'Staff Management',
        schedule: 'Shift Schedule',
        timesheets: 'Timesheets',
        'client-notes': 'Client Notes',
        billing: 'Billing & Invoices',
        reports: 'Reports',
        incidents: 'Incidents',
        compliance: 'Compliance & Checks',
        settings: 'Settings'
    };

    document.getElementById('page-title').textContent = titles[pageId] || pageId;
    currentPage = pageId;
    updateDashboard();

    // Refresh page-specific data
    if (pageId === 'timesheets' && typeof refreshTimesheets === 'function') refreshTimesheets();
    if (pageId === 'client-notes' && typeof refreshClientNotes === 'function') refreshClientNotes();
    if (pageId === 'incidents' && typeof refreshIncidents === 'function') refreshIncidents();
    // Compliance check is already done for billing, but we might want to re-run it to update UI state inside the page
    if (pageId === 'billing' && typeof checkBillingCompliance === 'function') checkBillingCompliance();
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        location.reload();
    }
}


async function updateDashboard() {
    if (currentPage !== 'dashboard') return;

    try {
        const [clients, staff, shifts, timesheets, incidents] = await Promise.all([
            DataService.getAll('clients'),
            DataService.getAll('staff'),
            DataService.getAll('schedules'),
            DataService.getAll('timesheets'),
            DataService.getAll('incidents')
        ]);

        // Top Metrics
        const clientsCount = document.getElementById('stat-clients');
        if (clientsCount) clientsCount.textContent = clients.length;

        const staffCount = document.getElementById('stat-staff');
        if (staffCount) staffCount.textContent = staff.filter(s => s.active).length;

        const shiftsCount = document.getElementById('stat-shifts');
        if (shiftsCount) shiftsCount.textContent = shifts.length;

        const pendingCount = document.getElementById('stat-pending');
        if (pendingCount) {
            const pending = timesheets.filter(t => t.status === 'pending').length;
            pendingCount.textContent = pending;
        }

        // Upcoming Shifts List
        const upcomingShiftsList = document.getElementById('upcoming-shifts');
        if (upcomingShiftsList) {
            const upcoming = shifts
                .filter(s => new Date(s.date) >= new Date().setHours(0, 0, 0, 0))
                .sort((a, b) => new Date(a.date) - new Date(b.date))
                .slice(0, 5);

            if (upcoming.length === 0) {
                upcomingShiftsList.innerHTML = '<li class="empty-state">No upcoming shifts</li>';
            } else {
                upcomingShiftsList.innerHTML = upcoming.map(shift => {
                    const staffMember = staff.find(s => s.id == shift.staffId);
                    const client = clients.find(c => c.id == shift.clientId);
                    return `
                        <li>
                            <div class="activity-icon">📅</div>
                            <div class="activity-info">
                                <strong>${staffMember?.name || 'Staff'}</strong> → ${client?.name || 'Client'}
                                <p>${shift.date} | ${shift.startTime} - ${shift.endTime}</p>
                            </div>
                        </li>
                    `;
                }).join('');
            }
        }

        // Recent Activity (Combination of incidents, new clients, etc.)
        const activityList = document.getElementById('activity-list');
        if (activityList) {
            const activities = [];

            incidents.forEach(i => activities.push({
                type: 'incident',
                date: new Date(i.createdAt),
                text: `Incident: ${i.type} reported by ${i.reportedBy}`,
                icon: '⚠️'
            }));

            timesheets.filter(t => t.status === 'pending').forEach(t => activities.push({
                type: 'timesheet',
                date: new Date(t.createdAt),
                text: `New timesheet from ${staff.find(s => s.id == t.staffId)?.name || 'Staff'}`,
                icon: '⏱️'
            }));

            const sortedActivities = activities
                .sort((a, b) => b.date - a.date)
                .slice(0, 5);

            if (sortedActivities.length === 0) {
                activityList.innerHTML = '<li class="empty-state">No recent activity</li>';
            } else {
                activityList.innerHTML = sortedActivities.map(a => `
                    <li>
                        <div class="activity-icon">${a.icon}</div>
                        <div class="activity-info">
                            <strong>${a.text}</strong>
                            <p>${a.date.toLocaleString()}</p>
                        </div>
                    </li>
                `).join('');
            }
        }

    } catch (error) {
        console.error('Error updating dashboard:', error);
    }
}

function openClientModal() {
    document.getElementById('client-modal').style.display = 'flex';
    document.querySelector('#client-modal h2').textContent = 'Add Client';
    const form = document.getElementById('client-form');
    form.onsubmit = saveClient;
}


function closeClientModal() {
    document.getElementById('client-modal').style.display = 'none';
    document.getElementById('client-form').reset();
}


async function saveClient(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.textContent = 'Saving...';
    btn.disabled = true;

    const client = {
        id: Date.now(),
        name: document.getElementById('client-name').value,
        email: document.getElementById('client-email').value,
        phone: document.getElementById('client-phone').value,
        careLevel: document.getElementById('client-level').value, // Fixed ID from client-care-level to client-level based on HTML check
        notes: document.getElementById('client-notes').value,
        status: 'active',
        createdAt: new Date().toISOString()
    };

    try {
        await DataService.create('clients', client);
        closeClientModal();
        await refreshClientTable();
        updateDashboard();
        Toast.success('Client added successfully!');
    } catch (error) {
        console.error('Error saving client:', error);
        Toast.error('Failed to add client');
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}


async function refreshClientTable() {
    const tbody = document.getElementById('clients-tbody');
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding: 20px;">Loading clients...</td></tr>';

    try {
        const clients = await DataService.getAll('clients');

        if (clients.length === 0) {
            tbody.innerHTML = '<tr class="empty-row"><td colspan="5" class="empty-state">No clients added yet</td></tr>';
            return;
        }

        tbody.innerHTML = clients.map(client => `
            <tr>
                <td><strong>${client.name}</strong></td>
                <td>${client.email || '—'}</td>
                <td><span class="badge">${client.careLevel}</span></td>
                <td><span class="badge active">${client.status}</span></td>
                <td>
                    <button class="action-small" onclick="editClient(${client.id})">Edit</button>
                    <button class="action-small danger" onclick="deleteClient(${client.id})">Delete</button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading clients:', error);
        tbody.innerHTML = '<tr><td colspan="5" class="error-state">Failed to load clients</td></tr>';
        Toast.error('Failed to load clients');
    }
}


async function deleteClient(id) {
    if (confirm('Delete this client? This action cannot be undone.')) {
        try {
            await DataService.delete('clients', id);
            await refreshClientTable();
            updateDashboard();
            Toast.success('Client deleted');
        } catch (error) {
            console.error('Error deleting client:', error);
            Toast.error('Failed to delete client');
        }
    }
}


async function editClient(id) {
    try {
        const client = await DataService.getById('clients', id);
        if (!client) {
            Toast.error('Client not found');
            return;
        }

        // Populate form with client data
        document.getElementById('client-name').value = client.name;
        document.getElementById('client-email').value = client.email || '';
        document.getElementById('client-phone').value = client.phone || '';

        // Fix for ID mismatch: HTML uses 'client-level', app.js used 'client-care-level'
        const levelSelect = document.getElementById('client-level') || document.getElementById('client-care-level');
        if (levelSelect) levelSelect.value = client.careLevel;

        document.getElementById('client-notes').value = client.notes || '';

        // Change form to edit mode
        const form = document.getElementById('client-form');
        form.onsubmit = async function (e) {
            e.preventDefault();
            const btn = e.target.querySelector('button[type="submit"]');
            const originalText = btn.textContent;
            btn.textContent = 'Updating...';
            btn.disabled = true;

            const updatedClient = {
                id: client.id, // Keep original ID
                name: document.getElementById('client-name').value,
                email: document.getElementById('client-email').value,
                phone: document.getElementById('client-phone').value,
                careLevel: levelSelect ? levelSelect.value : 'basic',
                notes: document.getElementById('client-notes').value,
                updatedAt: new Date().toISOString()
            }; // Removed spread ...client to ensure clean object update, relying on DataService merge if implemented, but here we reconstruct. 
            // Actually DataService.update merges, so we just pass updates. but let's pass full object for safety or just updates.
            // My DataService.update implementation merges: items[index] = { ...items[index], ...updates };
            // So passing just fields is fine.

            try {
                await DataService.update('clients', id, updatedClient);
                closeClientModal();
                await refreshClientTable();
                updateDashboard();
                Toast.success('Client updated successfully!');

                // Reset form to add mode
                form.onsubmit = saveClient;
            } catch (error) {
                console.error('Error updating client:', error);
                Toast.error('Failed to update client');
            } finally {
                btn.textContent = originalText;
                btn.disabled = false;
            }
        };

        openClientModal();
        document.querySelector('#client-modal h2').textContent = 'Edit Client';
    } catch (error) {
        console.error('Error fetching client for edit:', error);
        Toast.error('Error loading client details');
    }
}



async function openStaffModal() {
    document.getElementById('staff-modal').style.display = 'flex';
    document.querySelector('#staff-modal h2').textContent = 'Add Staff Member';
    const form = document.getElementById('staff-form');
    form.onsubmit = saveStaff;
    await populateStaffDropdowns();
}


function closeStaffModal() {
    document.getElementById('staff-modal').style.display = 'none';
    document.getElementById('staff-form').reset();
}


async function saveStaff(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.textContent = 'Saving...';
    btn.disabled = true;

    // Validate password for new staff
    const password = document.getElementById('staff-password').value;
    if (!password) {
        Toast.warning('Please set a login password for the new staff member.');
        btn.textContent = originalText;
        btn.disabled = false;
        return;
    }

    const ndisModule = document.getElementById('staff-ndis-module').checked;
    const cocSigned = document.getElementById('staff-coc').checked;
    const bankDetails = document.getElementById('staff-bank').checked;

    const onboardingComplete = ndisModule && cocSigned && bankDetails;

    const staff = {
        id: Date.now(),
        name: document.getElementById('staff-name').value,
        position: document.getElementById('staff-position').value,
        role: document.getElementById('staff-role').value || 'worker',
        email: document.getElementById('staff-email').value,
        password: password,
        phone: document.getElementById('staff-phone').value,

        // Compliance
        wwccExpiry: document.getElementById('staff-wwcc').value,
        policeExpiry: document.getElementById('staff-police').value,
        firstAidExpiry: document.getElementById('staff-firstaid').value,

        // Onboarding
        ndisModule: ndisModule,
        cocSigned: cocSigned,
        bankDetails: bankDetails,
        onboardingComplete: onboardingComplete,

        active: document.getElementById('staff-active').checked,
        createdAt: new Date().toISOString()
    };

    try {
        await DataService.create('staff', staff);
        closeStaffModal();
        await refreshStaffTable();
        updateDashboard();

        if (onboardingComplete) {
            Toast.success('Staff member added successfully! Onboarding complete.');
        } else {
            Toast.warning('Staff added. Payment blocked until onboarding complete.');
        }
    } catch (error) {
        console.error('Error saving staff:', error);
        Toast.error('Failed to add staff member');
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}


async function refreshStaffTable() {
    const tbody = document.getElementById('staff-tbody');
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 20px;">Loading staff...</td></tr>';

    try {
        const staff = await DataService.getAll('staff');

        if (staff.length === 0) {
            tbody.innerHTML = '<tr class="empty-row"><td colspan="6" class="empty-state">No staff members added yet</td></tr>';
            return;
        }

        tbody.innerHTML = staff.map(member => {
            // Check compliance
            const now = new Date();
            let issues = [];
            if (!member.onboardingComplete) issues.push('Onboarding Incomplete');
            if (member.wwccExpiry && new Date(member.wwccExpiry) < now) issues.push('WWCC Expired');

            const statusBadge = member.onboardingComplete
                ? `<span class="badge ${member.active ? 'active' : 'inactive'}">${member.active ? 'Active' : 'Inactive'}</span>`
                : `<span class="badge danger">Onboarding Pending</span>`;

            return `
            <tr>
                <td><strong>${member.name}</strong></td>
                <td>${member.position}</td>
                <td><span class="badge info" style="text-transform: capitalize;">${member.role || 'worker'}</span></td>
                <td>${member.email}<br><small>${member.phone || ''}</small></td>
                <td>${statusBadge}</td>
                <td>
                    <button class="action-small" onclick="editStaff(${member.id})">Edit</button>
                    <button class="action-small danger" onclick="deleteStaff(${member.id})">Delete</button>
                </td>
            </tr>
        `}).join('');
    } catch (error) {
        console.error('Error loading staff:', error);
        tbody.innerHTML = '<tr><td colspan="6" class="error-state">Failed to load staff</td></tr>';
        Toast.error('Failed to load staff list');
    }
}

async function deleteStaff(id) {
    if (confirm('Delete this staff member? This will remove their access to the platform.')) {
        try {
            await DataService.delete('staff', id);
            await refreshStaffTable();
            updateDashboard();
            Toast.success('Staff member deleted');
        } catch (error) {
            console.error('Error deleting staff:', error);
            Toast.error('Failed to delete staff member');
        }
    }
}


async function editStaff(id) {
    try {
        const member = await DataService.getById('staff', id);
        if (!member) {
            Toast.error('Staff member not found');
            return;
        }

        // Populate form with staff data
        document.getElementById('staff-name').value = member.name;
        document.getElementById('staff-position').value = member.position;
        document.getElementById('staff-role').value = member.role || 'worker';
        document.getElementById('staff-email').value = member.email;
        document.getElementById('staff-phone').value = member.phone || '';
        document.getElementById('staff-active').checked = member.active;

        // Compliance
        document.getElementById('staff-wwcc').value = member.wwccExpiry || '';
        document.getElementById('staff-police').value = member.policeExpiry || '';
        document.getElementById('staff-firstaid').value = member.firstAidExpiry || '';

        // Onboarding
        document.getElementById('staff-ndis-module').checked = member.ndisModule || false;
        document.getElementById('staff-coc').checked = member.cocSigned || false;
        document.getElementById('staff-bank').checked = member.bankDetails || false;

        // Clear password field
        document.getElementById('staff-password').value = '';

        // Change form to edit mode
        const form = document.getElementById('staff-form');

        form.onsubmit = async function (e) {
            e.preventDefault();
            const btn = e.target.querySelector('button[type="submit"]');
            const originalText = btn.textContent;
            btn.textContent = 'Updating...';
            btn.disabled = true;

            const newPassword = document.getElementById('staff-password').value;
            const ndisModule = document.getElementById('staff-ndis-module').checked;
            const cocSigned = document.getElementById('staff-coc').checked;
            const bankDetails = document.getElementById('staff-bank').checked;
            const onboardingComplete = ndisModule && cocSigned && bankDetails;

            const updatedStaff = {
                id: member.id, // Ensure ID persistence
                name: document.getElementById('staff-name').value,
                position: document.getElementById('staff-position').value,
                role: document.getElementById('staff-role').value,
                email: document.getElementById('staff-email').value,
                password: newPassword ? newPassword : member.password,
                phone: document.getElementById('staff-phone').value,

                wwccExpiry: document.getElementById('staff-wwcc').value,
                policeExpiry: document.getElementById('staff-police').value,
                firstAidExpiry: document.getElementById('staff-firstaid').value,

                ndisModule: ndisModule,
                cocSigned: cocSigned,
                bankDetails: bankDetails,
                onboardingComplete: onboardingComplete,

                active: document.getElementById('staff-active').checked,
                updatedAt: new Date().toISOString()
            };

            try {
                await DataService.update('staff', id, updatedStaff);
                closeStaffModal();
                await refreshStaffTable();
                updateDashboard();

                if (!onboardingComplete && member.onboardingComplete) {
                    Toast.warning('Warning: Onboarding status Incomplete. Payments blocked.');
                } else {
                    Toast.success('Staff member updated successfully!');
                }

                // Reset form to add mode
                form.onsubmit = saveStaff;
            } catch (error) {
                console.error('Error updating staff:', error);
                Toast.error('Failed to update staff member');
            } finally {
                btn.textContent = originalText;
                btn.disabled = false;
            }
        };

        openStaffModal();
        document.querySelector('#staff-modal h2').textContent = 'Edit Staff Member';
    } catch (error) {
        console.error('Error fetching staff for edit:', error);
        Toast.error('Error loading staff details');
    }
}



async function openScheduleModal() {
    document.getElementById('schedule-modal').style.display = 'flex';
    // Show loading state in dropdowns?
    document.getElementById('schedule-staff').innerHTML = '<option>Loading...</option>';
    document.getElementById('schedule-client').innerHTML = '<option>Loading...</option>';
    await populateScheduleDropdowns();
}

function closeScheduleModal() {
    document.getElementById('schedule-modal').style.display = 'none';
    document.getElementById('schedule-form').reset();
}

async function populateScheduleDropdowns() {
    try {
        const [staff, clients] = await Promise.all([
            DataService.getAll('staff'),
            DataService.getAll('clients')
        ]);

        document.getElementById('schedule-staff').innerHTML =
            '<option value="">Select Staff Member</option>' +
            staff.map(s => `<option value="${s.id}">${s.name}</option>`).join('');

        document.getElementById('schedule-client').innerHTML =
            '<option value="">Select Client</option>' +
            clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

        // Also update staff select in staff modal if open? 
        // Logic says populateStaffDropdowns calls this, so it should be fine.
    } catch (error) {
        console.error('Error populating dropdowns:', error);
        Toast.error('Failed to load selection data');
    }
}

async function populateStaffDropdowns() {
    await populateScheduleDropdowns();
}

async function saveSchedule(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.textContent = 'Creating...';
    btn.disabled = true;

    const schedule = {
        id: Date.now(),
        staffId: document.getElementById('schedule-staff').value,
        clientId: document.getElementById('schedule-client').value,
        date: document.getElementById('schedule-date').value,
        startTime: document.getElementById('schedule-start').value,
        endTime: document.getElementById('schedule-end').value,
        notes: document.getElementById('schedule-notes').value,
        createdAt: new Date().toISOString()
    };

    try {
        await DataService.create('schedules', schedule);
        closeScheduleModal();
        await refreshScheduleView();
        updateDashboard();
        Toast.success('Shift created successfully!');
    } catch (error) {
        console.error('Error creating shift:', error);
        Toast.error('Failed to create shift');
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}

async function refreshScheduleView() {
    const scheduleCalendar = document.getElementById('schedule-calendar');
    if (scheduleCalendar) {
        scheduleCalendar.innerHTML = '<p class="loading-text">Loading schedule...</p>';
    }

    try {
        const [shifts, staff, clients] = await Promise.all([
            DataService.getAll('schedules'),
            DataService.getAll('staff'),
            DataService.getAll('clients')
        ]);

        // Update dashboard preview (if element exists)
        const schedulePreview = document.getElementById('schedule-preview');
        if (schedulePreview) {
            if (shifts.length === 0) {
                schedulePreview.innerHTML = '<p class="empty-state">No upcoming shifts scheduled</p>';
            } else {
                schedulePreview.innerHTML = shifts.slice(0, 5).map(shift => {
                    const staffMember = staff.find(s => s.id == shift.staffId);
                    const client = clients.find(c => c.id == shift.clientId);
                    return `
                        <div style="padding: 8px; border-left: 3px solid #C41E8C; margin-bottom: 8px; background: #f5f7fa; border-radius: 4px;">
                            <strong>${staffMember?.name || 'Unknown'}</strong> → ${client?.name || 'Unknown'}
                            <br><small>${shift.date} ${shift.startTime}-${shift.endTime}</small>
                        </div>
                    `;
                }).join('');
            }
        }

        // Update schedule calendar page
        if (!scheduleCalendar) return;

        if (shifts.length === 0) {
            scheduleCalendar.innerHTML = '<p class="empty-state">No shifts scheduled. Create a shift to get started.</p>';
            return;
        }

        // Group shifts by date
        const shiftsByDate = {};
        shifts.forEach(shift => {
            if (!shiftsByDate[shift.date]) {
                shiftsByDate[shift.date] = [];
            }
            shiftsByDate[shift.date].push(shift);
        });

        // Sort dates
        const sortedDates = Object.keys(shiftsByDate).sort();

        scheduleCalendar.innerHTML = sortedDates.map(date => {
            const dateShifts = shiftsByDate[date];
            // Handle date safety
            const parts = date.split('-');
            // Construct safe date: year, month-1, day
            const dateObj = new Date(parts[0], parts[1] - 1, parts[2]);

            const formattedDate = dateObj.toLocaleDateString('en-GB', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });

            return `
                <div style="margin-bottom: 24px;">
                    <h3 style="color: var(--primary); margin-bottom: 12px; font-size: 16px; font-weight: 600;">
                        ${formattedDate}
                    </h3>
                    <div style="display: grid; gap: 12px;">
                        ${dateShifts.map(shift => {
                const staffMember = staff.find(s => s.id == shift.staffId);
                const client = clients.find(c => c.id == shift.clientId);
                return `
                                <div style="background: white; padding: 16px; border-radius: 8px; border-left: 4px solid var(--secondary); box-shadow: var(--shadow);">
                                    <div style="display: flex; justify-content: space-between; align-items: start;">
                                        <div style="flex: 1;">
                                            <div style="font-weight: 600; color: var(--text-primary); margin-bottom: 8px;">
                                                ${staffMember?.name || 'Unknown Staff'} → ${client?.name || 'Unknown Client'}
                                            </div>
                                            <div style="font-size: 14px; color: var(--text-secondary); margin-bottom: 4px;">
                                                ⏰ ${shift.startTime} - ${shift.endTime}
                                            </div>
                                            ${shift.notes ? `<div style="font-size: 13px; color: var(--text-secondary); margin-top: 8px; padding: 8px; background: var(--bg-light); border-radius: 4px;">📝 ${shift.notes}</div>` : ''}
                                        </div>
                                        <button class="action-small danger" onclick="deleteSchedule(${shift.id})" style="margin-left: 12px;">Delete</button>
                                    </div>
                                </div>
                            `;
            }).join('')}
                    </div>
                </div>
            `;
        }).join('');
    } catch (error) {
        console.error('Error loading schedule:', error);
        if (scheduleCalendar) scheduleCalendar.innerHTML = '<p class="error-state">Failed to load schedule</p>';
        Toast.error('Failed to load schedule');
    }
}


async function deleteSchedule(id) {
    if (confirm('Delete this shift? This action cannot be undone.')) {
        try {
            await DataService.delete('schedules', id);
            await refreshScheduleView();
            updateDashboard();
            Toast.success('Shift deleted');
        } catch (error) {
            console.error('Error deleting shift:', error);
            Toast.error('Failed to delete shift');
        }
    }
}


function saveSettings() {
    const settings = {
        orgName: document.getElementById('org-name').value,
        orgEmail: document.getElementById('org-email').value,
        orgPhone: document.getElementById('org-phone').value
    };
    localStorage.setItem('settings', JSON.stringify(settings));
    alert('Settings saved!');
}

function loadSettings() {
    const settings = JSON.parse(localStorage.getItem('settings') || '{}');
    document.getElementById('org-name').value = settings.orgName || 'Carters Care Group';
    document.getElementById('org-email').value = settings.orgEmail || '';
    document.getElementById('org-phone').value = settings.orgPhone || '';
}

async function exportData() {
    try {
        const [clients, staff, schedules, timesheets, incidents, invoices] = await Promise.all([
            DataService.getAll('clients'),
            DataService.getAll('staff'),
            DataService.getAll('schedules'),
            DataService.getAll('timesheets'),
            DataService.getAll('incidents'),
            DataService.getAll('invoices')
        ]);

        const data = {
            clients,
            staff,
            schedules,
            timesheets,
            incidents,
            invoices,
            settings: JSON.parse(localStorage.getItem('settings') || '{}'),
            exportDate: new Date().toISOString()
        };

        const dataStr = JSON.stringify(data, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `carters-care-export-${Date.now()}.json`;
        link.click();
        URL.revokeObjectURL(url);
        Toast.success('Data exported successfully');
    } catch (error) {
        console.error('Export error:', error);
        Toast.error('Failed to export data');
    }
}

function importData() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = function (e) {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onload = function (event) {
            try {
                const data = JSON.parse(event.target.result);
                localStorage.setItem('clients', JSON.stringify(data.clients || []));
                localStorage.setItem('staff', JSON.stringify(data.staff || []));
                localStorage.setItem('schedules', JSON.stringify(data.schedules || []));
                localStorage.setItem('settings', JSON.stringify(data.settings || {}));
                alert('Data imported successfully!');
                location.reload();
            } catch (error) {
                alert('Error importing data: ' + error.message);
            }
        };
        reader.readAsText(file);
    };
    input.click();
}

function clearData() {
    if (confirm('WARNING: This will delete all data. Are you sure?')) {
        if (confirm('Really? This action cannot be undone!')) {
            localStorage.clear();
            alert('All data has been cleared.');
            location.reload();
        }
    }
}

document.addEventListener('DOMContentLoaded', async function () {
    console.log('Initializing Carters Care Platform...');

    // Navigation setup
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function () {
            const pageId = this.getAttribute('data-page');
            goToPage(pageId);
        });
    });

    // User dropdown setup
    document.addEventListener('click', function (event) {
        if (event.target.classList.contains('user-button')) {
            const dropdown = event.target.nextElementSibling;
            if (dropdown) dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
        }
    });

    // Initial data load
    loadSettings();

    // Run initial refreshes in parallel
    await Promise.all([
        updateDashboard(),
        refreshClientTable(),
        refreshStaffTable(),
        refreshScheduleView(),
        // These are from features.js
        typeof checkBillingCompliance === 'function' ? checkBillingCompliance() : Promise.resolve()
    ]);

    // Hide loading screen if it exists
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) {
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }, 800);
    }

    console.log('Platform ready.');
});

