// Features.js - Timesheets, Client Notes, Billing, Reports, Incidents

// ===== TIMESHEETS =====

async function openTimesheetModal() {
    document.getElementById('timesheet-modal').style.display = 'flex';
    document.getElementById('timesheet-staff').innerHTML = '<option>Loading...</option>';
    document.getElementById('timesheet-client').innerHTML = '<option>Loading...</option>';
    await populateTimesheetDropdowns();
}

function closeTimesheetModal() {
    document.getElementById('timesheet-modal').style.display = 'none';
    document.getElementById('timesheet-form').reset();
}


async function populateTimesheetDropdowns() {
    try {
        const [staff, clients] = await Promise.all([
            DataService.getAll('staff'),
            DataService.getAll('clients')
        ]);

        document.getElementById('timesheet-staff').innerHTML =
            '<option value="">Select Staff Member</option>' +
            staff.map(s => `<option value="${s.id}">${s.name}</option>`).join('');

        document.getElementById('timesheet-client').innerHTML =
            '<option value="">Select Client</option>' +
            clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    } catch (error) {
        console.error('Error populating timesheet dropdowns:', error);
        Toast.error('Failed to load selection data');
    }
}


async function saveTimesheet(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.textContent = 'Submitting...';
    btn.disabled = true;

    const timesheet = {
        id: Date.now(),
        staffId: document.getElementById('timesheet-staff').value,
        clientId: document.getElementById('timesheet-client').value,
        date: document.getElementById('timesheet-date').value,
        startTime: document.getElementById('timesheet-start').value,
        endTime: document.getElementById('timesheet-end').value,
        description: document.getElementById('timesheet-description').value,
        status: 'pending',
        createdAt: new Date().toISOString()
    };

    try {
        await DataService.create('timesheets', timesheet);
        closeTimesheetModal();
        await refreshTimesheets();
        updateDashboard();
        Toast.success('Timesheet submitted successfully!');
    } catch (error) {
        console.error('Error saving timesheet:', error);
        Toast.error('Failed to submit timesheet');
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}

function getTimesheets() {
    return JSON.parse(localStorage.getItem('timesheets') || '[]');
}


async function refreshTimesheets() {
    const container = document.getElementById('timesheets-list');
    if (!container) return;

    container.innerHTML = '<p class="loading-text">Loading timesheets...</p>';

    try {
        const [timesheets, staff, clients] = await Promise.all([
            DataService.getAll('timesheets'),
            DataService.getAll('staff'),
            DataService.getAll('clients')
        ]);

        // Handle filter
        const filter = document.getElementById('timesheet-filter');
        const filterValue = filter ? filter.value : 'all';
        const filteredTimesheets = filterValue === 'all' ? timesheets : timesheets.filter(t => t.status === filterValue);

        if (filteredTimesheets.length === 0) {
            container.innerHTML = '<p class="empty-state">No timesheets found</p>';
            return;
        }

        container.innerHTML = filteredTimesheets.map(ts => {
            const staffMember = staff.find(s => s.id == ts.staffId);
            const client = clients.find(c => c.id == ts.clientId);
            const statusClass = ts.status === 'approved' ? 'success' : ts.status === 'rejected' ? 'danger' : 'warning';

            return `
                <div class="timesheet-card">
                    <div class="timesheet-header">
                        <div>
                            <strong>${staffMember?.name || 'Unknown'}</strong> → ${client?.name || 'Unknown'}
                            <br><small>${ts.date} | ${ts.startTime} - ${ts.endTime}</small>
                        </div>
                        <span class="badge ${statusClass}">${ts.status}</span>
                    </div>
                    <p class="timesheet-description">${ts.description}</p>
                    <div class="timesheet-actions">
                        ${ts.status === 'pending' ? `
                            <button class="btn-small btn-success" onclick="approveTimesheet(${ts.id})">Approve</button>
                            <button class="btn-small btn-danger" onclick="rejectTimesheet(${ts.id})">Reject</button>
                        ` : ''}
                        <button class="btn-small" onclick="deleteTimesheet(${ts.id})">Delete</button>
                    </div>
                </div>
            `;
        }).join('');

        await checkBillingCompliance();
    } catch (error) {
        console.error('Error refreshing timesheets:', error);
        container.innerHTML = '<p class="error-state">Failed to load timesheets</p>';
        Toast.error('Failed to load timesheets');
    }
}


async function approveTimesheet(id) {
    try {
        const timesheet = await DataService.getById('timesheets', id);
        if (!timesheet) return;

        // Check Compliance / Onboarding
        const staffMember = await DataService.getById('staff', timesheet.staffId);

        if (staffMember && !staffMember.onboardingComplete) {
            Toast.error(`PAYMENT BLOCKED: ${staffMember.name}\nStaff member has not completed mandatory onboarding.`);
            return;
        }

        const updates = {
            status: 'approved',
            approvedAt: new Date().toISOString()
        };

        await DataService.update('timesheets', id, updates);
        await refreshTimesheets();
        updateDashboard();
        Toast.success('Timesheet approved!');
    } catch (error) {
        console.error('Error approving timesheet:', error);
        Toast.error('Failed to approve timesheet');
    }
}


async function rejectTimesheet(id) {
    const reason = prompt('Reason for rejection:');
    if (reason) {
        try {
            const updates = {
                status: 'rejected',
                rejectionReason: reason,
                rejectedAt: new Date().toISOString()
            };

            await DataService.update('timesheets', id, updates);
            await refreshTimesheets();
            Toast.warning('Timesheet rejected');
        } catch (error) {
            console.error('Error rejecting timesheet:', error);
            Toast.error('Failed to reject timesheet');
        }
    }
}


async function deleteTimesheet(id) {
    if (confirm('Delete this timesheet?')) {
        try {
            await DataService.delete('timesheets', id);
            await refreshTimesheets();
            Toast.success('Timesheet deleted');
        } catch (error) {
            console.error('Error deleting timesheet:', error);
            Toast.error('Failed to delete timesheet');
        }
    }
}


function filterTimesheets() {
    refreshTimesheets(); // refreshTimesheets now handles reading the filter value directly
}

// ===== CLIENT NOTES =====

async function openClientNoteModal() {
    document.getElementById('client-note-modal').style.display = 'flex';
    document.getElementById('note-client').innerHTML = '<option>Loading...</option>';
    await populateClientNoteDropdowns();
}

function closeClientNoteModal() {
    document.getElementById('client-note-modal').style.display = 'none';
    document.getElementById('client-note-form').reset();
}

async function populateClientNoteDropdowns() {
    try {
        const clients = await DataService.getAll('clients');

        document.getElementById('note-client').innerHTML =
            '<option value="">Select Client</option>' +
            clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

        document.getElementById('note-client-filter').innerHTML =
            '<option value="all">All Clients</option>' +
            clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    } catch (error) {
        console.error('Error populating note dropdowns:', error);
        Toast.error('Failed to load clients');
    }
}


async function saveClientNote(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.textContent = 'Saving...';
    btn.disabled = true;

    const note = {
        id: Date.now(),
        clientId: document.getElementById('note-client').value,
        type: document.getElementById('note-type').value,
        date: document.getElementById('note-date').value,
        content: document.getElementById('note-content').value,
        urgent: document.getElementById('note-urgent').checked,
        createdBy: 'admin', // In a real app, this would be the logged-in user
        createdAt: new Date().toISOString()
    };

    try {
        await DataService.create('clientNotes', note);
        closeClientNoteModal();
        await refreshClientNotes();
        Toast.success('Client note saved successfully!');
    } catch (error) {
        console.error('Error saving note:', error);
        Toast.error('Failed to save note');
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}

function getClientNotes() {
    return JSON.parse(localStorage.getItem('clientNotes') || '[]');
}


async function refreshClientNotes() {
    const container = document.getElementById('client-notes-list');
    if (!container) return;

    container.innerHTML = '<p class="loading-text">Loading notes...</p>';

    try {
        const [notes, clients] = await Promise.all([
            DataService.getAll('clientNotes'),
            DataService.getAll('clients')
        ]);

        // Filtering
        const clientFilter = document.getElementById('note-client-filter') ? document.getElementById('note-client-filter').value : 'all';
        const typeFilter = document.getElementById('note-type-filter') ? document.getElementById('note-type-filter').value : 'all';

        let filteredNotes = notes;
        if (clientFilter !== 'all') filteredNotes = filteredNotes.filter(n => n.clientId == clientFilter);
        if (typeFilter !== 'all') filteredNotes = filteredNotes.filter(n => n.type === typeFilter);

        if (filteredNotes.length === 0) {
            container.innerHTML = '<p class="empty-state">No client notes found</p>';
            return;
        }

        container.innerHTML = filteredNotes.map(note => {
            const client = clients.find(c => c.id == note.clientId);
            const typeColors = {
                general: 'secondary',
                medical: 'danger',
                behavioral: 'warning',
                incident: 'danger'
            };

            return `
                <div class="note-card ${note.urgent ? 'urgent' : ''}">
                    <div class="note-header">
                        <div>
                            <strong>${client?.name || 'Unknown Client'}</strong>
                            ${note.urgent ? '<span class="urgent-badge">⚠️ URGENT</span>' : ''}
                            <br><small>${note.date} | ${note.type}</small>
                        </div>
                        <span class="badge ${typeColors[note.type]}">${note.type}</span>
                    </div>
                    <p class="note-content">${note.content}</p>
                    <div class="note-footer">
                        <small>By ${note.createdBy} on ${new Date(note.createdAt).toLocaleString()}</small>
                        <button class="btn-small btn-danger" onclick="deleteClientNote(${note.id})">Delete</button>
                    </div>
                </div>
            `;
        }).join('');

        await checkBillingCompliance();
    } catch (error) {
        console.error('Error refreshing notes:', error);
        container.innerHTML = '<p class="error-state">Failed to load notes</p>';
        Toast.error('Failed to load notes');
    }
}


async function deleteClientNote(id) {
    if (confirm('Delete this note?')) {
        try {
            await DataService.delete('clientNotes', id);
            await refreshClientNotes();
            Toast.success('Note deleted');
        } catch (error) {
            console.error('Error deleting note:', error);
            Toast.error('Failed to delete note');
        }
    }
}


function filterClientNotes() {
    refreshClientNotes();
}

// ===== BILLING & COMPLIANCE =====

// ===== BILLING & COMPLIANCE =====
async function checkBillingCompliance() {
    try {
        const [timesheets, notes] = await Promise.all([
            DataService.getAll('timesheets'),
            DataService.getAll('clientNotes')
        ]);

        const billingLocked = document.getElementById('billing-locked');
        const billingContent = document.getElementById('billing-content');
        const billingNav = document.getElementById('billing-nav');
        const lockIcon = billingNav?.querySelector('.lock-icon');
        const requirementsList = document.getElementById('billing-requirements');

        const approvedTimesheets = timesheets.filter(t => t.status === 'approved');
        const hasTimesheets = approvedTimesheets.length > 0;
        const hasNotes = notes.length > 0;

        const requirements = [];
        if (!hasTimesheets) requirements.push('Submit and approve at least one timesheet');
        if (!hasNotes) requirements.push('Add at least one client note');

        const isCompliant = requirements.length === 0;

        if (billingLocked && billingContent) {
            if (isCompliant) {
                billingLocked.style.display = 'none';
                billingContent.style.display = 'block';
                if (lockIcon) lockIcon.style.display = 'none';
            } else {
                billingLocked.style.display = 'flex';
                billingContent.style.display = 'none';
                if (lockIcon) lockIcon.style.display = 'inline';

                if (requirementsList) {
                    requirementsList.innerHTML = requirements.map(r => `<li>${r}</li>`).join('');
                }
            }
        }

        return isCompliant;
    } catch (error) {
        console.error('Error checking compliance:', error);
        return false;
    }
}


async function validateAndGenerateInvoices() {
    const isCompliant = await checkBillingCompliance();
    if (!isCompliant) {
        Toast.warning('Please complete all requirements before generating invoices');
        return;
    }

    const startDate = document.getElementById('invoice-start').value;
    const endDate = document.getElementById('invoice-end').value;
    const type = document.getElementById('invoice-type').value;

    if (!startDate || !endDate || !type) {
        Toast.warning('Please fill in all invoice generation fields');
        return;
    }

    // --- Enhanced: Actually generate an Invoice Object ---
    try {
        const btn = document.querySelector('.billing-actions button');
        btn.innerHTML = '<span class="icon">🔄</span> Generating...';
        btn.disabled = true;

        const timesheets = await DataService.getAll('timesheets');
        const clients = await DataService.getAll('clients');

        // Filter timesheets for period and approved status
        const start = new Date(startDate);
        const end = new Date(endDate);

        const billableSheets = timesheets.filter(t => {
            const date = new Date(t.date);
            return t.status === 'approved' && date >= start && date <= end;
        });

        if (billableSheets.length === 0) {
            Toast.info('No approved timesheets found for this period');
            btn.innerHTML = '<span class="icon">📊</span> Validate & Generate Invoices';
            btn.disabled = false;
            return;
        }

        // Generate Invoice
        const invoice = {
            id: Date.now(),
            date: new Date().toISOString(),
            periodStart: startDate,
            periodEnd: endDate,
            type: type,
            items: billableSheets.map(t => {
                const client = clients.find(c => c.id == t.clientId);
                return {
                    description: `Service for ${client?.name || 'Unknown'}`,
                    date: t.date,
                    hours: calculateHours(t.startTime, t.endTime),
                    rate: 65.00 // standard rate placeholder
                };
            }),
            totalAmount: 0 // logic below
        };

        invoice.totalAmount = invoice.items.reduce((sum, item) => sum + (item.hours * item.rate), 0);

        // Save to 'invoices' (new resource)
        await DataService.create('invoices', invoice);

        Toast.success(`Invoice generated for $${invoice.totalAmount.toFixed(2)}`);

        // Refresh Invoices List
        await refreshInvoicesList();

    } catch (e) {
        console.error(e);
        Toast.error('Error generating invoices');
    } finally {
        const btn = document.querySelector('.billing-actions button');
        btn.innerHTML = '<span class="icon">📊</span> Validate & Generate Invoices';
        btn.disabled = false;
    }
}

function calculateHours(start, end) {
    const [h1, m1] = start.split(':').map(Number);
    const [h2, m2] = end.split(':').map(Number);
    return Math.max(0, (h2 + m2 / 60) - (h1 + m1 / 60));
}

async function refreshInvoicesList() {
    const list = document.getElementById('invoices-list');
    list.innerHTML = '<p>Loading invoices...</p>';
    try {
        const invoices = await DataService.getAll('invoices');
        if (invoices.length === 0) {
            list.innerHTML = '<p class="empty-state">No invoices generated</p>';
            return;
        }

        list.innerHTML = invoices.map(inv => `
            <div class="metric-card" style="margin-bottom:10px; border-left-color: var(--secondary);">
                <div class="metric-header" style="margin-bottom: 5px;">
                    <h3>INV-#${inv.id} (${inv.type})</h3>
                    <span class="badge success">$${inv.totalAmount.toFixed(2)}</span>
                </div>
                <p class="metric-description">${inv.periodStart} to ${inv.periodEnd} | ${inv.items.length} items</p>
                <div style="margin-top: 10px;">
                    <button class="btn-small">Download PDF</button>
                    <button class="btn-small danger">Void</button>
                </div>
            </div>
        `).join('');

        // Update metrics
        const totalBilled = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
        document.getElementById('total-billed').textContent = `$${totalBilled.toFixed(2)}`;
        document.getElementById('total-outstanding').textContent = `$${totalBilled.toFixed(2)}`; // Assuming all outstanding for now

    } catch (e) {
        list.innerHTML = '<p>Error loading invoices</p>';
    }
}

function showInvoiceTab(tab) {
    // Tab switching logic
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

// ===== REPORTS =====

async function generateReport(type) {
    const reportOutput = document.getElementById('report-output');
    reportOutput.style.display = 'block';
    reportOutput.innerHTML = '<p class="loading-text">Generating report...</p>';

    try {
        let content = '';
        const now = new Date();

        if (type === 'client-service') {
            const [clients, timesheets] = await Promise.all([
                DataService.getAll('clients'),
                DataService.getAll('timesheets')
            ]);

            content = `<h3>Client Service Summary</h3><p>Generated on ${now.toLocaleString()}</p><div class="table-container"><table><thead><tr><th>Client</th><th>Total Hours</th><th>Last Service</th></tr></thead><tbody>`;

            clients.forEach(c => {
                const clientSheets = timesheets.filter(t => t.clientId == c.id && t.status === 'approved');
                let totalHours = 0;
                clientSheets.forEach(t => {
                    const [h1, m1] = t.startTime.split(':').map(Number);
                    const [h2, m2] = t.endTime.split(':').map(Number);
                    totalHours += Math.max(0, (h2 + m2 / 60) - (h1 + m1 / 60));
                });
                const lastSheet = clientSheets.sort((a, b) => new Date(b.date) - new Date(a.date))[0];

                content += `<tr><td>${c.name}</td><td>${totalHours.toFixed(2)} hrs</td><td>${lastSheet ? lastSheet.date : '-'}</td></tr>`;
            });
            content += '</tbody></table></div>';

        } else if (type === 'staff-compliance') {
            await runComplianceCheck();
            return; // runComplianceCheck handles the output

        } else {
            content = `<p>Report type '${type}' generation coming soon.</p>`;
        }

        reportOutput.innerHTML = content;

    } catch (error) {
        console.error('Error generating report:', error);
        reportOutput.innerHTML = '<p class="error-state">Failed to generate report</p>';
    }
}


async function runComplianceCheck() {
    const reportOutput = document.getElementById('report-output');
    reportOutput.style.display = 'block';
    reportOutput.innerHTML = '<p class="loading-text">Running compliance check...</p>';

    try {
        const staff = await DataService.getAll('staff');
        const now = new Date();
        const nonCompliant = staff.filter(s => {
            if (!s.onboardingComplete) return true;
            if (s.wwccExpiry && new Date(s.wwccExpiry) < now) return true;
            return false;
        });

        let html = `
            <h3>Compliance Report</h3>
            <div class="metric-card" style="border-left-color: ${nonCompliant.length > 0 ? 'var(--danger)' : 'var(--success)'}">
                <h3>${nonCompliant.length} Issues Found</h3>
                <p>Staff with expired docs or incomplete onboarding</p>
            </div>
            <div class="table-container">
                <table>
                    <thead><tr><th>Staff Member</th><th>Issue</th><th>Action</th></tr></thead>
                    <tbody>
        `;

        if (nonCompliant.length === 0) {
            html += `<tr><td colspan="3" style="text-align:center">✅ All staff are compliant</td></tr>`;
        } else {
            nonCompliant.forEach(s => {
                let issues = [];
                if (!s.onboardingComplete) issues.push('Onboarding Incomplete');
                if (s.wwccExpiry && new Date(s.wwccExpiry) < now) issues.push('WWCC Expired');

                html += `
                    <tr>
                        <td>${s.name}</td>
                        <td style="color: var(--danger)">${issues.join(', ')}</td>
                        <td><button class="btn-small" onclick="editStaff(${s.id})">Fix</button></td>
                    </tr>
                `;
            });
        }

        html += '</tbody></table></div>';
        reportOutput.innerHTML = html;
    } catch (error) {
        console.error('Error running compliance check:', error);
        reportOutput.innerHTML = '<p class="error-state">Failed to run compliance check</p>';
    }
}

function openCustomReportBuilder() {
    alert('Custom Report Builder\n\nThis feature will allow you to build custom reports with:\n- Custom date ranges\n- Multiple data sources\n- Custom filters\n- Export options\n\nComing soon!');
}

// ===== INCIDENTS =====

// ===== INCIDENTS =====
async function openIncidentModal() {
    document.getElementById('incident-modal').style.display = 'flex';
    document.getElementById('incident-staff').innerHTML = '<option>Loading...</option>';
    document.getElementById('incident-client').innerHTML = '<option>Loading...</option>';
    await populateIncidentDropdowns();
}

function closeIncidentModal() {
    document.getElementById('incident-modal').style.display = 'none';
    document.getElementById('incident-form').reset();
}

async function populateIncidentDropdowns() {
    try {
        const [staff, clients] = await Promise.all([
            DataService.getAll('staff'),
            DataService.getAll('clients')
        ]);

        document.getElementById('incident-staff').innerHTML =
            '<option value="">Select Staff (if applicable)</option>' +
            staff.map(s => `<option value="${s.id}">${s.name}</option>`).join('');

        document.getElementById('incident-client').innerHTML =
            '<option value="">Select Client (if applicable)</option>' +
            clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    } catch (error) {
        console.error('Error populating incident dropdowns:', error);
        Toast.error('Failed to load selection data');
    }
}


async function saveIncident(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const originalText = btn.textContent;
    btn.textContent = 'Reporting...';
    btn.disabled = true;

    const incident = {
        id: Date.now(),
        datetime: document.getElementById('incident-datetime').value,
        severity: document.getElementById('incident-severity').value,
        type: document.getElementById('incident-type').value,
        clientId: document.getElementById('incident-client').value,
        staffId: document.getElementById('incident-staff').value,
        location: document.getElementById('incident-location').value,
        description: document.getElementById('incident-description').value,
        action: document.getElementById('incident-action').value,

        emergencyContacted: document.getElementById('incident-emergency').checked,
        familyNotified: document.getElementById('incident-family').checked,
        ndisReportable: document.getElementById('incident-ndis-reportable').checked,
        waNotified: document.getElementById('incident-wa-notified').checked,

        status: 'open',
        reportedBy: 'admin',
        createdAt: new Date().toISOString()
    };

    try {
        await DataService.create('incidents', incident);
        closeIncidentModal();
        await refreshIncidents();

        // Critical Notification Simulation
        if (incident.severity === 'critical' || incident.severity === 'high') {
            Toast.error('CRITICAL INCIDENT REPORTED. Notifications sent to Management.');
        } else {
            Toast.success('Incident reported successfully');
        }
    } catch (error) {
        console.error('Error saving incident:', error);
        Toast.error('Failed to report incident');
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}


function getIncidents() {
    return JSON.parse(localStorage.getItem('incidents') || '[]');
}

async function refreshIncidents() {
    const container = document.getElementById('incidents-list');
    if (!container) return;

    container.innerHTML = '<p class="loading-text">Loading incidents...</p>';

    try {
        const [incidents, staff, clients] = await Promise.all([
            DataService.getAll('incidents'),
            DataService.getAll('staff'),
            DataService.getAll('clients')
        ]);

        if (incidents.length === 0) {
            container.innerHTML = '<p class="empty-state">No incidents reported</p>';
            return;
        }

        container.innerHTML = incidents.map(incident => {
            const staffMember = incident.staffId ? staff.find(s => s.id == incident.staffId) : null;
            const client = incident.clientId ? clients.find(c => c.id == incident.clientId) : null;

            const severityColors = {
                low: 'success',
                medium: 'warning',
                high: 'danger',
                critical: 'danger'
            };

            return `
                <div class="incident-card severity-${incident.severity}">
                    <div class="incident-header">
                        <div>
                            <strong style="color: var(--${severityColors[incident.severity] || 'info'})">${incident.type.toUpperCase()}</strong>
                            <br><small>${new Date(incident.datetime).toLocaleString()}</small>
                        </div>
                        <div>
                            <span class="badge ${severityColors[incident.severity]}">${incident.severity}</span>
                            <span class="badge">${incident.status}</span>
                        </div>
                    </div>
                    <div class="incident-details">
                        ${client ? `<p><strong>Client:</strong> ${client.name}</p>` : ''}
                        ${staffMember ? `<p><strong>Staff:</strong> ${staffMember.name}</p>` : ''}
                        <p><strong>Location:</strong> ${incident.location}</p>
                        <p><strong>Description:</strong> ${incident.description}</p>
                        <p><strong>Action Taken:</strong> ${incident.action}</p>
                        
                        <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px;">
                            ${incident.emergencyContacted ? '<span class="warning-text">⚠️ Emergency Contacted</span>' : ''}
                            ${incident.familyNotified ? '<span style="color:var(--success)">✅ Family Notified</span>' : ''}
                            ${incident.ndisReportable ? '<span style="color:var(--danger)">🔴 NDIS Reportable</span>' : ''}
                            ${incident.waNotified ? '<span style="color:var(--secondary)">🔵 WA Dept Notified</span>' : ''}
                        </div>
                    </div>
                    <div class="incident-footer">
                        <small>Reported by ${incident.reportedBy || 'admin'} on ${new Date(incident.createdAt).toLocaleString()}</small>
                        <div class="incident-actions">
                            ${incident.status !== 'closed' ? `<button class="btn-small" onclick="updateIncidentStatus(${incident.id}, 'investigating')">Investigate</button>` : ''}
                            ${incident.status !== 'resolved' && incident.status !== 'closed' ? `<button class="btn-small btn-success" onclick="updateIncidentStatus(${incident.id}, 'resolved')">Resolve</button>` : ''}
                            ${incident.status === 'resolved' ? `<button class="btn-small btn-secondary" onclick="updateIncidentStatus(${incident.id}, 'closed')">Close Report</button>` : ''}
                            <button class="btn-small btn-danger" onclick="deleteIncident(${incident.id})">Delete</button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    } catch (error) {
        console.error('Error refreshing incidents:', error);
        container.innerHTML = '<p class="error-state">Failed to load incidents</p>';
    }
}



async function updateIncidentStatus(id, status) {
    try {
        await DataService.update('incidents', id, { status: status, updatedAt: new Date().toISOString() });
        await refreshIncidents();
        Toast.success(`Incident status: ${status}`);
    } catch (error) {
        console.error('Error updating incident:', error);
        Toast.error('Failed to update incident');
    }
}

async function deleteIncident(id) {
    if (confirm('Delete this incident report? This action cannot be undone.')) {
        try {
            await DataService.delete('incidents', id);
            await refreshIncidents();
            Toast.success('Incident deleted');
        } catch (error) {
            console.error('Error deleting incident:', error);
            Toast.error('Failed to delete incident');
        }
    }
}

function filterIncidents() {
    // Filter logic here
    refreshIncidents();
}

// Initialize on page load (Now handled by app.js or individual page loads)
// window.addEventListener('DOMContentLoaded', ...);

