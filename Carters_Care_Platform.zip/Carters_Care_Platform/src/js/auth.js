// Authentication and Session Management
const AUTH_KEY = 'carters_auth_session';
const STAFF_KEY = 'staff'; // Key used in app.js for staff storage

// Super Admin Credentials
const SUPER_ADMIN = {
    email: 'parker@cdxi.au',
    password: 'D0ntPanic!',
    name: 'Super Admin',
    role: 'admin'
};

// Role Definitions
const ROLES = {
    ADMIN: 'admin',
    MANAGER: 'manager',
    COORDINATOR: 'coordinator',
    WORKER: 'worker',
    NO_ACCESS: 'no_access'
};

function getStaffUsers() {
    return JSON.parse(localStorage.getItem(STAFF_KEY) || '[]');
}

function isAuthenticated() {
    const session = localStorage.getItem(AUTH_KEY);
    if (!session) return false;

    try {
        const sessionData = JSON.parse(session);
        const now = new Date().getTime();

        // Check if session is still valid (24 hours)
        if (sessionData.expiry && sessionData.expiry > now) {
            return true;
        }

        // Session expired
        localStorage.removeItem(AUTH_KEY);
        return false;
    } catch (error) {
        localStorage.removeItem(AUTH_KEY);
        return false;
    }
}

async function login(email, password) {
    console.log('Attempting login:', email);

    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: email, password })
        });

        if (response.ok) {
            const data = await response.json();
            createSession(data.user);
            return true;
        }
    } catch (e) {
        console.warn('Backend auth unavailable, falling back to local auth');
    }

    // --- Local Fallback ---

    // 1. Check Super Admin
    if (email.toLowerCase() === SUPER_ADMIN.email.toLowerCase() && password === SUPER_ADMIN.password) {
        createSession(SUPER_ADMIN);
        return true;
    }

    // 2. Check Staff Users
    const staff = getStaffUsers();
    const user = staff.find(s =>
        s.email && s.email.toLowerCase() === email.toLowerCase() &&
        s.password && s.password === password &&
        s.active
    );

    if (user) {
        const sessionUser = {
            email: user.email,
            name: user.name,
            role: user.role || ROLES.WORKER,
            id: user.id
        };
        createSession(sessionUser);
        return true;
    }

    return false;
}

function createSession(user) {
    const expiry = new Date().getTime() + (24 * 60 * 60 * 1000); // 24 hours
    const sessionData = {
        ...user,
        loginTime: new Date().toISOString(),
        expiry: expiry
    };
    localStorage.setItem(AUTH_KEY, JSON.stringify(sessionData));
}

async function handleLogin(e) {
    if (e) e.preventDefault();

    const emailInput = document.getElementById('login-username');
    const passwordInput = document.getElementById('login-password');
    const errorDiv = document.getElementById('login-error');

    if (!emailInput || !passwordInput) {
        console.error('Login inputs not found');
        return;
    }

    const email = emailInput.value.trim();
    const password = passwordInput.value;


    if (await login(email, password)) {
        // Success
        if (errorDiv) errorDiv.style.display = 'none';
        checkAuth();
    } else {
        // Failure
        if (errorDiv) {
            errorDiv.textContent = 'Invalid email or password.';
            errorDiv.style.display = 'block';

            // Add shake animation class
            const form = document.getElementById('login-form');
            form.classList.add('shake');
            setTimeout(() => {
                form.classList.remove('shake');
            }, 500);
        }
    }
}

function logout() {
    localStorage.removeItem(AUTH_KEY);
    window.location.reload();
}

function getSession() {
    try {
        return JSON.parse(localStorage.getItem(AUTH_KEY));
    } catch (e) {
        return null;
    }
}

function getSessionUser() {
    const session = getSession();
    return session ? session.name : null;
}

function getSessionRole() {
    const session = getSession();
    return session ? (session.role || 'worker') : null;
}

// Permission & UI Logic
function checkAuth() {
    const loginPage = document.getElementById('login-page');
    const app = document.getElementById('app');

    if (!isAuthenticated()) {
        if (loginPage) loginPage.style.display = 'flex';
        if (app) app.style.display = 'none';
        return false;
    } else {
        if (loginPage) loginPage.style.display = 'none';
        if (app) app.style.display = 'flex';

        applyPermissions();
        return true;
    }
}

function applyPermissions() {
    const role = getSessionRole();
    if (!role) return;

    console.log('Applying permissions for role:', role);

    // Default Access: Worker (very limited)
    // Levels:
    // Admin: All
    // Manager: Operational (Staff, Schedule, Clients, Reports)
    // Coordinator: Care (Schedule, Clients, Notes)
    // Worker: Self (Schedule view, Timesheets)

    // Using 'data-page' attribute on sidebar buttons
    const allNavs = document.querySelectorAll('.nav-item');

    allNavs.forEach(nav => {
        const page = nav.getAttribute('data-page');
        let allowed = false;

        if (role === ROLES.ADMIN) {
            allowed = true;
        } else if (role === ROLES.MANAGER) {
            // Manager: All except maybe Billing for some orgs, but here we allow most.
            // Settings allowed but limited by content below.
            allowed = true;
        } else if (role === ROLES.COORDINATOR) {
            // Coordinator: Schedule, Clients, Staff (View), Notes, Incidents, Settings (Password)
            if (['schedule', 'clients', 'staff', 'client-notes', 'incidents', 'settings'].includes(page)) allowed = true;
        } else {
            // Worker
            // Can see: Schedule (My Shifts), Timesheets, Client Notes (Add), Incidents (Report), Settings (Password)
            if (['schedule', 'timesheets', 'client-notes', 'incidents', 'settings'].includes(page)) allowed = true;
        }

        // Hide/Show
        nav.style.display = allowed ? 'flex' : 'none';
    });

    // Special: Billing is strict Admin/Manager
    const billingNav = document.getElementById('billing-nav');
    if (billingNav) {
        if (role === ROLES.ADMIN || role === ROLES.MANAGER) {
            billingNav.style.display = 'flex';
        } else {
            billingNav.style.display = 'none';
        }
    }

    // Settings Page Granular Permissions
    const settingsOrg = document.getElementById('settings-org');
    const settingsData = document.getElementById('settings-data');

    if (settingsOrg && settingsData) {
        if (role === ROLES.ADMIN) {
            settingsOrg.style.display = 'block';
            settingsData.style.display = 'block';
        } else {
            // Hide Org and Data handling for non-admins
            settingsOrg.style.display = 'none';
            settingsData.style.display = 'none';
        }
    }

    // Update Profile Name
    const userMenu = document.querySelector('.user-menu span');
    if (userMenu) userMenu.textContent = `(${role}) ${getSessionUser() || 'User'}`;
}

// Initialize
if (typeof window !== 'undefined') {
    window.addEventListener('load', checkAuth);
    // Bind login form if exists
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.onsubmit = handleLogin;
    }
}
