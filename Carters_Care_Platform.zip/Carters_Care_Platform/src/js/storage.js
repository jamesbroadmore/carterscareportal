/**
 * DataService - Centralized Data Access Layer
 * "Wired Front and Back" - Communicates with the Express API.
 * 
 * Version: 2.0.0 (Full Stack)
 */

const API_BASE = '/api';

const DataService = {
    // Helper for fetch with error handling
    async _request(endpoint, options = {}) {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
        }

        if (response.status === 204) return true;
        return await response.json();
    },

    // Generic Getter
    async getAll(resource) {
        try {
            return await this._request(`/${resource}`);
        } catch (e) {
            console.error(`Error fetching ${resource}:`, e);
            // Fallback to localStorage if API fails (useful for local development without server)
            const local = localStorage.getItem(resource);
            return local ? JSON.parse(local) : [];
        }
    },

    // Generic Get by ID
    async getById(resource, id) {
        try {
            return await this._request(`/${resource}/${id}`);
        } catch (e) {
            console.error(`Error fetching ${resource}/${id}:`, e);
            const items = await this.getAll(resource);
            return items.find(item => item.id == id);
        }
    },

    // Generic Create
    async create(resource, item) {
        try {
            const result = await this._request(`/${resource}`, {
                method: 'POST',
                body: JSON.stringify(item)
            });
            return result;
        } catch (e) {
            console.error(`Error creating in ${resource}:`, e);
            // Local fallback
            const items = await this.getAll(resource);
            if (!item.id) item.id = Date.now();
            items.push(item);
            localStorage.setItem(resource, JSON.stringify(items));
            return item;
        }
    },

    // Generic Update
    async update(resource, id, updates) {
        try {
            return await this._request(`/${resource}/${id}`, {
                method: 'PUT',
                body: JSON.stringify(updates)
            });
        } catch (e) {
            console.error(`Error updating ${resource}:`, e);
            // Local fallback
            const items = await this.getAll(resource);
            const index = items.findIndex(item => item.id == id);
            if (index !== -1) {
                items[index] = { ...items[index], ...updates };
                localStorage.setItem(resource, JSON.stringify(items));
                return items[index];
            }
            throw e;
        }
    },

    // Generic Delete
    async delete(resource, id) {
        try {
            return await this._request(`/${resource}/${id}`, {
                method: 'DELETE'
            });
        } catch (e) {
            console.error(`Error deleting from ${resource}:`, e);
            // Local fallback
            let items = await this.getAll(resource);
            items = items.filter(item => item.id != id);
            localStorage.setItem(resource, JSON.stringify(items));
            return true;
        }
    },

    // Nuke everything (Dev tool)
    async clearAll() {
        // This is dangerous, so we just clear local for now
        localStorage.clear();
        return true;
    }
};

// --- Legacy Compatibility Layer (Deprecated) ---
// Note: These remain synchronous to avoid breaking existing UI calls that don't await.
// They will primarily use localStorage. For a real app, these should be removed.

function getClients() {
    return JSON.parse(localStorage.getItem('clients') || '[]');
}

function getStaff() {
    return JSON.parse(localStorage.getItem('staff') || '[]');
}

function getSchedules() {
    return JSON.parse(localStorage.getItem('schedules') || '[]');
}

function saveToStorage(key, item) {
    const items = JSON.parse(localStorage.getItem(key) || '[]');
    items.push(item);
    localStorage.setItem(key, JSON.stringify(items));
}

function deleteFromStorage(key, id) {
    let items = JSON.parse(localStorage.getItem(key) || '[]');
    items = items.filter(item => item.id !== id);
    localStorage.setItem(key, JSON.stringify(items));
}

function updateInStorage(key, id, updatedItem) {
    let items = JSON.parse(localStorage.getItem(key) || '[]');
    items = items.map(item => item.id === id ? updatedItem : item);
    localStorage.setItem(key, JSON.stringify(items));
}

// Global expose
window.DataService = DataService;
